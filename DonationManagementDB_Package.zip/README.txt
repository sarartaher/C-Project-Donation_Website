Donation Management Database – Setup Guide
--------------------------------------

FILES INCLUDED:
1) DonationManagementDB.sql  -> Full database build script (tables, views, seed data)
2) SmokeTest.sql             -> Optional demo script (creates donor/project/fundraiser, inserts donation)
3) README.txt                -> This guide

REQUIREMENTS:
- Microsoft SQL Server 2022 (Developer or Express)
- SQL Server Management Studio (SSMS)

SETUP STEPS:
1. Open SSMS and connect to your SQL Server instance (e.g., localhost or .\SQLEXPRESS).
2. File -> Open -> File... -> select DonationManagementDB.sql.
   - Make sure the database dropdown says "master".
   - Click Execute (F5).
   - This creates the DonationManagementDB database with all tables, constraints, views, and seed data (6 categories).
3. Verification (new query):
   USE DonationManagementDB;
   SELECT COUNT(*) AS Categories FROM dbo.DonationCategory;   -- should be 6
   SELECT TOP 3 * FROM dbo.v_SegmentTotalsBasic;              -- should return rows/columns.
4. Optional: run SmokeTest.sql (Execute).
   - Creates demo donor/project/fundraiser if missing.
   - Inserts a donation of 1000 to Gaza Relief fundraiser.
   - Shows results in v_FundraiserCollected, v_SegmentTotals, and v_SegmentTotalsBasic.
5. Application connection string:
   Windows Auth:
   "ConnectionStrings": {
     "DefaultConnection": "Server=localhost;Database=DonationManagementDB;Trusted_Connection=True;TrustServerCertificate=True;"
   }
   SQL Login:
   "ConnectionStrings": {
     "DefaultConnection": "Server=localhost;Database=DonationManagementDB;User Id=sa;Password=YOUR_SA_PASSWORD;TrustServerCertificate=True;"
   }

Done. Database is ready.
