/* =======================================================================
   DonationManagementDB.sql
   Donation Management System – Full Database Build Script (SQL Server 2022+)
   -----------------------------------------------------------------------
   What this script does:
    1) Creates database DonationManagementDB (if missing)
    2) Creates all tables, PK/UK/FK, CHECK constraints, and helpful indexes
    3) Creates 3 views used by UI (fundraiser totals & segment dashboards)
    4) Seeds 6 donation categories (incl. Eid/Ramadan)
   Notes:
    - Idempotent: tables/views are created only if missing; seed uses IF NOT EXISTS
    - Safe to re-run without dropping anything
    - Views are in dedicated batches to avoid "CREATE VIEW must be only statement" error
   ======================================================================= */

-- 0) Create database if not exists
IF DB_ID(N'DonationManagementDB') IS NULL
BEGIN
  PRINT 'Creating database DonationManagementDB...';
  CREATE DATABASE DonationManagementDB;
END
ELSE
BEGIN
  PRINT 'Database DonationManagementDB already exists.';
END
GO

-- 1) Use the database
USE DonationManagementDB;
GO

-- Recommended session options
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* =======================================================================
   2) TABLES
   -----------------------------------------------------------------------
   Conventions:
     - Identity INT PKs
     - NVARCHAR for text; VARBINARY for password hashes (app handles hashing)
     - CHECK constraints enforce enums and numeric limits
     - Foreign keys use NO ACTION unless noted
   ======================================================================= */

-- 2.1 Admin (system operators; actions traced via AuditLog)
IF OBJECT_ID('dbo.Admin','U') IS NULL
BEGIN
  CREATE TABLE dbo.Admin (
    AdminID       INT IDENTITY(1,1) PRIMARY KEY,
    Name          NVARCHAR(100)      NOT NULL,
    Email         NVARCHAR(255)      NOT NULL UNIQUE,  -- UK: each admin email unique
    PasswordHash  VARBINARY(256)     NOT NULL,         -- store hash, not plaintext
    Role          NVARCHAR(50)       NOT NULL,         -- e.g., Super, Manager
    IsActive      BIT                NOT NULL CONSTRAINT DF_Admin_IsActive DEFAULT 1,
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Admin_CreatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedAt     DATETIME2          NULL
  );
END
GO

-- 2.2 Donor (end users who donate)
IF OBJECT_ID('dbo.Donor','U') IS NULL
BEGIN
  CREATE TABLE dbo.Donor (
    DonorID       INT IDENTITY(1,1) PRIMARY KEY,
    Name          NVARCHAR(100)      NOT NULL,
    Email         NVARCHAR(255)      NOT NULL UNIQUE,  -- UK: each donor email unique
    PasswordHash  VARBINARY(256)     NOT NULL,
    Phone         NVARCHAR(30)       NULL,
    Address       NVARCHAR(255)      NULL,
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Donor_CreatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedAt     DATETIME2          NULL
  );
END
GO

-- 2.3 DonationCategory (segments; includes Eid/Ramadan seasonal)
IF OBJECT_ID('dbo.DonationCategory','U') IS NULL
BEGIN
  CREATE TABLE dbo.DonationCategory (
    CategoryID    INT IDENTITY(1,1) PRIMARY KEY,
    Name          NVARCHAR(100)      NOT NULL UNIQUE,  -- UK: segment name unique
    Description   NVARCHAR(500)      NULL,
    Priority      INT                NOT NULL,
    IsSeasonal    BIT                NOT NULL CONSTRAINT DF_Category_IsSeasonal DEFAULT 0,
    Season        NVARCHAR(20)       NULL,             -- e.g., 'Eid/Ramadan'
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Category_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Category_Priority CHECK (Priority BETWEEN 1 AND 5)  -- filter by priority
  );
END
GO

-- 2.4 Project (belongs to a category/segment)
IF OBJECT_ID('dbo.Project','U') IS NULL
BEGIN
  CREATE TABLE dbo.Project (
    ProjectID     INT IDENTITY(1,1) PRIMARY KEY,
    CategoryID    INT                NOT NULL,
    Title         NVARCHAR(150)      NOT NULL,
    Description   NVARCHAR(MAX)      NULL,
    StartDate     DATE               NULL,
    EndDate       DATE               NULL,
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Project_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Project_Category FOREIGN KEY (CategoryID)
      REFERENCES dbo.DonationCategory(CategoryID) ON DELETE NO ACTION
  );
  CREATE INDEX IX_Project_CategoryID ON dbo.Project(CategoryID);
END
GO

-- 2.5 Fundraiser (belongs to project; holds a target; can be active/inactive)
IF OBJECT_ID('dbo.Fundraiser','U') IS NULL
BEGIN
  CREATE TABLE dbo.Fundraiser (
    FundraiserID  INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID     INT                NOT NULL,
    Title         NVARCHAR(150)      NOT NULL,
    TargetAmount  DECIMAL(18,2)      NOT NULL,
    StartDate     DATE               NULL,
    EndDate       DATE               NULL,
    IsActive      BIT                NOT NULL CONSTRAINT DF_Fundraiser_IsActive DEFAULT 1,
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Fundraiser_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Fundraiser_Project FOREIGN KEY (ProjectID)
      REFERENCES dbo.Project(ProjectID) ON DELETE NO ACTION,
    CONSTRAINT CK_Fundraiser_Target CHECK (TargetAmount > 0)
  );
  CREATE INDEX IX_Fundraiser_ProjectID ON dbo.Fundraiser(ProjectID);
END
GO

-- 2.6 Cart (open/checked_out/abandoned) per donor
IF OBJECT_ID('dbo.Cart','U') IS NULL
BEGIN
  CREATE TABLE dbo.Cart (
    CartID        INT IDENTITY(1,1) PRIMARY KEY,
    DonorID       INT                NOT NULL,
    Status        NVARCHAR(20)       NOT NULL CONSTRAINT DF_Cart_Status DEFAULT 'open',
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Cart_CreatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedAt     DATETIME2          NULL,
    CONSTRAINT CK_Cart_Status CHECK (Status IN ('open','checked_out','abandoned')),
    CONSTRAINT FK_Cart_Donor FOREIGN KEY (DonorID)
      REFERENCES dbo.Donor(DonorID) ON DELETE NO ACTION
  );
  CREATE INDEX IX_Cart_DonorID ON dbo.Cart(DonorID);
END
GO

-- 2.7 CartItem (each row = intent to donate to a fundraiser)
IF OBJECT_ID('dbo.CartItem','U') IS NULL
BEGIN
  CREATE TABLE dbo.CartItem (
    CartItemID    INT IDENTITY(1,1) PRIMARY KEY,
    CartID        INT                NOT NULL,
    FundraiserID  INT                NOT NULL,
    Amount        DECIMAL(18,2)      NOT NULL,
    CONSTRAINT CK_CartItem_Amount CHECK (Amount > 0),
    CONSTRAINT FK_CartItem_Cart FOREIGN KEY (CartID)
      REFERENCES dbo.Cart(CartID) ON DELETE CASCADE,     -- delete items if cart removed
    CONSTRAINT FK_CartItem_Fundraiser FOREIGN KEY (FundraiserID)
      REFERENCES dbo.Fundraiser(FundraiserID) ON DELETE NO ACTION
  );
  CREATE INDEX IX_CartItem_CartID ON dbo.CartItem(CartID);
  CREATE INDEX IX_CartItem_FundraiserID ON dbo.CartItem(FundraiserID);
END
GO

-- 2.8 Donation (created at checkout; status: initiated/succeeded/refunded/failed)
IF OBJECT_ID('dbo.Donation','U') IS NULL
BEGIN
  CREATE TABLE dbo.Donation (
    DonationID    INT IDENTITY(1,1) PRIMARY KEY,
    DonorID       INT                NOT NULL,
    FundraiserID  INT                NOT NULL,
    Amount        DECIMAL(18,2)      NOT NULL,
    Currency      CHAR(3)            NOT NULL CONSTRAINT DF_Donation_Currency DEFAULT 'USD',
    Status        NVARCHAR(20)       NOT NULL CONSTRAINT DF_Donation_Status DEFAULT 'initiated',
    Date          DATETIME2          NOT NULL CONSTRAINT DF_Donation_Date DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Donation_Amount CHECK (Amount > 0),
    CONSTRAINT CK_Donation_Status CHECK (Status IN ('initiated','succeeded','refunded','failed')),
    CONSTRAINT FK_Donation_Donor FOREIGN KEY (DonorID)
      REFERENCES dbo.Donor(DonorID) ON DELETE NO ACTION,
    CONSTRAINT FK_Donation_Fundraiser FOREIGN KEY (FundraiserID)
      REFERENCES dbo.Fundraiser(FundraiserID) ON DELETE NO ACTION
  );
  -- Helpful indexes for reporting
  CREATE INDEX IX_Donation_Fundraiser_Status ON dbo.Donation(FundraiserID, Status);
  CREATE INDEX IX_Donation_Status_Fundraiser ON dbo.Donation(Status, FundraiserID);
  CREATE INDEX IX_Donation_Fundraiser_Date ON dbo.Donation(FundraiserID, Date);
END
GO

-- 2.9 Payment (1:Many with Donation for retries/partials/refunds)
IF OBJECT_ID('dbo.Payment','U') IS NULL
BEGIN
  CREATE TABLE dbo.Payment (
    PaymentID       INT IDENTITY(1,1) PRIMARY KEY,
    DonationID      INT                NOT NULL,
    Amount          DECIMAL(18,2)      NOT NULL,
    PaymentMethod   NVARCHAR(50)       NULL,            -- e.g., Card, MobileWallet
    PaymentStatus   NVARCHAR(20)       NOT NULL,        -- pending/succeeded/failed/refunded
    Gateway         NVARCHAR(50)       NULL,            -- optional: Stripe, SSLCOMMERZ, etc.
    GatewayTxnId    NVARCHAR(100)      NULL,            -- optional: unique per gateway
    TransactionDate DATETIME2          NOT NULL CONSTRAINT DF_Payment_TxnDate DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Payment_Status CHECK (PaymentStatus IN ('pending','succeeded','failed','refunded')),
    CONSTRAINT FK_Payment_Donation FOREIGN KEY (DonationID)
      REFERENCES dbo.Donation(DonationID) ON DELETE NO ACTION
  );
  -- Avoid duplicates if gateway guarantees unique txn id
  CREATE UNIQUE INDEX UX_Payment_GatewayTxnId ON dbo.Payment(GatewayTxnId) WHERE GatewayTxnId IS NOT NULL;
  CREATE INDEX IX_Payment_DonationID ON dbo.Payment(DonationID);
END
GO

-- 2.10 Review (one per donor per project)
IF OBJECT_ID('dbo.Review','U') IS NULL
BEGIN
  CREATE TABLE dbo.Review (
    ReviewID      INT IDENTITY(1,1) PRIMARY KEY,
    DonorID       INT                NOT NULL,
    ProjectID     INT                NOT NULL,
    Rating        TINYINT            NOT NULL,          -- 1..5
    Comment       NVARCHAR(1000)     NULL,
    Date          DATETIME2          NOT NULL CONSTRAINT DF_Review_Date DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Review_Rating CHECK (Rating BETWEEN 1 AND 5),
    CONSTRAINT UQ_Review_Donor_Project UNIQUE (DonorID, ProjectID),
    CONSTRAINT FK_Review_Donor FOREIGN KEY (DonorID)
      REFERENCES dbo.Donor(DonorID) ON DELETE NO ACTION,
    CONSTRAINT FK_Review_Project FOREIGN KEY (ProjectID)
      REFERENCES dbo.Project(ProjectID) ON DELETE NO ACTION
  );
  CREATE INDEX IX_Review_ProjectID ON dbo.Review(ProjectID);
END
GO

-- 2.11 WorksOfOrganization (stories/outcomes; optionally linked to project)
IF OBJECT_ID('dbo.WorksOfOrganization','U') IS NULL
BEGIN
  CREATE TABLE dbo.WorksOfOrganization (
    WorkID        INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID     INT                NULL,
    Title         NVARCHAR(150)      NOT NULL,
    Description   NVARCHAR(MAX)      NULL,
    Date          DATE               NULL,
    MediaURL      NVARCHAR(500)      NULL,
    CONSTRAINT FK_Work_Project FOREIGN KEY (ProjectID)
      REFERENCES dbo.Project(ProjectID) ON DELETE SET NULL
  );
  CREATE INDEX IX_Work_ProjectID ON dbo.WorksOfOrganization(ProjectID);
END
GO

-- 2.12 Volunteer (community members supporting projects/works)
IF OBJECT_ID('dbo.Volunteer','U') IS NULL
BEGIN
  CREATE TABLE dbo.Volunteer (
    VolunteerID   INT IDENTITY(1,1) PRIMARY KEY,
    Name          NVARCHAR(100)      NOT NULL,
    Email         NVARCHAR(255)      NOT NULL UNIQUE,   -- UK: email unique
    Phone         NVARCHAR(30)       NULL,
    Address       NVARCHAR(255)      NULL,
    Skills        NVARCHAR(300)      NULL,
    Availability  NVARCHAR(100)      NULL,
    CreatedAt     DATETIME2          NOT NULL CONSTRAINT DF_Volunteer_CreatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedAt     DATETIME2          NULL
  );
END
GO

-- 2.13 VolunteerAssignment (assign volunteers to projects or works)
IF OBJECT_ID('dbo.VolunteerAssignment','U') IS NULL
BEGIN
  CREATE TABLE dbo.VolunteerAssignment (
    AssignmentID  INT IDENTITY(1,1) PRIMARY KEY,
    VolunteerID   INT                NOT NULL,
    ProjectID     INT                NULL,
    WorkID        INT                NULL,
    RoleTask      NVARCHAR(100)      NULL,              -- optional label of task
    Status        NVARCHAR(20)       NOT NULL CONSTRAINT DF_VAssign_Status DEFAULT 'active',
    AssignedDate  DATETIME2          NOT NULL CONSTRAINT DF_VAssign_AssignedDate DEFAULT SYSUTCDATETIME(),
    Hours         DECIMAL(6,2)       NULL,              -- optional hours logged
    CONSTRAINT CK_VAssign_Status CHECK (Status IN ('active','completed','cancelled')),
    CONSTRAINT FK_VAssign_Volunteer FOREIGN KEY (VolunteerID)
      REFERENCES dbo.Volunteer(VolunteerID) ON DELETE CASCADE,
    CONSTRAINT FK_VAssign_Project FOREIGN KEY (ProjectID)
      REFERENCES dbo.Project(ProjectID) ON DELETE SET NULL,
    CONSTRAINT FK_VAssign_Work FOREIGN KEY (WorkID)
      REFERENCES dbo.WorksOfOrganization(WorkID) ON DELETE SET NULL
  );
  -- Optional dedup rule: exact same triple (VolunteerID, ProjectID, WorkID) only once
  -- CREATE UNIQUE INDEX UQ_VAssign_Vol_Project_Work ON dbo.VolunteerAssignment(VolunteerID, ProjectID, WorkID);
END
GO

-- 2.14 AuditLog (centralized audit; links to Admin and polymorphic entity ref)
IF OBJECT_ID('dbo.AuditLog','U') IS NULL
BEGIN
  CREATE TABLE dbo.AuditLog (
    LogID         INT IDENTITY(1,1) PRIMARY KEY,
    AdminID       INT                NOT NULL,
    Action        NVARCHAR(150)      NOT NULL,          -- CREATE/UPDATE/DELETE/APPROVE/etc.
    EntityType    NVARCHAR(100)      NOT NULL,          -- e.g., 'Project', 'Fundraiser'
    EntityId      NVARCHAR(100)      NOT NULL,          -- PK value of the entity (as text)
    OldValues     NVARCHAR(MAX)      NULL,              -- (optional) JSON of old values
    NewValues     NVARCHAR(MAX)      NULL,              -- (optional) JSON of new values
    IpAddress     NVARCHAR(45)       NULL,
    CorrelationId NVARCHAR(64)       NULL,
    Timestamp     DATETIME2          NOT NULL CONSTRAINT DF_Audit_Timestamp DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Audit_Admin FOREIGN KEY (AdminID)
      REFERENCES dbo.Admin(AdminID) ON DELETE NO ACTION
  );
  CREATE INDEX IX_Audit_AdminID ON dbo.AuditLog(AdminID);
  CREATE INDEX IX_Audit_Entity ON dbo.AuditLog(EntityType, EntityId);
END
GO

/* =======================================================================
   3) VIEWS (UI helpers)
   -----------------------------------------------------------------------
   v_FundraiserCollected : per-fundraiser collected totals (from Donation)
   v_SegmentTotals       : admin dashboard (target, collected, coverage)
   v_SegmentTotalsBasic  : donor view (segment, priority, collected)
   NOTE: each CREATE OR ALTER VIEW is in its own batch (GO)
   ======================================================================= */

-- 3.1 Per-fundraiser totals
CREATE OR ALTER VIEW dbo.v_FundraiserCollected
AS
SELECT
  f.FundraiserID,
  SUM(CASE WHEN d.Status = 'succeeded' THEN d.Amount ELSE 0 END) AS Collected,
  MAX(CASE WHEN d.Status = 'succeeded' THEN d.Date   ELSE NULL END) AS LastSucceededAt
FROM dbo.Fundraiser f
LEFT JOIN dbo.Donation d
  ON d.FundraiserID = f.FundraiserID
GROUP BY f.FundraiserID;
GO

-- 3.2 Segment totals (admin)
CREATE OR ALTER VIEW dbo.v_SegmentTotals
AS
SELECT
  c.CategoryID,
  c.Name AS Segment,
  c.Priority,
  SUM(f.TargetAmount) AS SegmentTarget,
  SUM(fc.Collected)   AS SegmentCollected,
  CAST(
    CASE WHEN SUM(f.TargetAmount) > 0
         THEN 100.0 * SUM(fc.Collected) / SUM(f.TargetAmount)
         ELSE NULL END AS DECIMAL(6,2)
  ) AS CoveragePct,
  MAX(fc.LastSucceededAt) AS LastUpdated
FROM dbo.DonationCategory c
JOIN dbo.Project p    ON p.CategoryID = c.CategoryID
JOIN dbo.Fundraiser f ON f.ProjectID  = p.ProjectID
LEFT JOIN dbo.v_FundraiserCollected fc ON fc.FundraiserID = f.FundraiserID
GROUP BY c.CategoryID, c.Name, c.Priority;
GO

-- 3.3 Segment totals (donor – simplified)
CREATE OR ALTER VIEW dbo.v_SegmentTotalsBasic
AS
SELECT CategoryID, Segment, Priority, SegmentCollected
FROM dbo.v_SegmentTotals;
GO

/* =======================================================================
   4) SEED DATA (6 segments; insert only if missing)
   ======================================================================= */

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Orphanage Support')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Orphanage Support', N'Food, shelter, education', 4, 0, NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Water in Africa')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Water in Africa', N'Clean water & sanitation', 4, 0, NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Gaza Relief')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Gaza Relief', N'Emergency humanitarian aid', 5, 0, NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Old Age Home Care')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Old Age Home Care', N'Elderly housing & health', 3, 0, NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Zakat')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Zakat', N'Religiously guided giving', 3, 0, NULL);

IF NOT EXISTS (SELECT 1 FROM dbo.DonationCategory WHERE Name = N'Eid/Ramadan')
INSERT INTO dbo.DonationCategory (Name, Description, Priority, IsSeasonal, Season)
VALUES (N'Eid/Ramadan', N'Seasonal drives bringing smiles to poor families', 4, 1, N'Eid/Ramadan');

PRINT 'DonationManagementDB build complete.';
