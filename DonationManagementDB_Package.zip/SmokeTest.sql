/* =======================================================================
   SmokeTest.sql
   Donation Management DB – Quick Post-Setup Verification
   -----------------------------------------------------------------------
   What this does:
     - Uses DonationManagementDB
     - Ensures a donor exists (demo_donor@example.com)
     - Ensures a Gaza Relief project and fundraiser exist
     - Inserts a succeeded donation (1000)
     - Displays dashboard views to verify rollups
   Idempotent: safe to re-run; it reuses existing rows if present.
   ======================================================================= */

USE DonationManagementDB;
GO

-- 1) Ensure demo donor exists
DECLARE @DemoEmail NVARCHAR(255) = N'demo_donor@example.com';
DECLARE @DonorID INT = (SELECT TOP 1 DonorID FROM dbo.Donor WHERE Email = @DemoEmail);
IF @DonorID IS NULL
BEGIN
  INSERT INTO dbo.Donor (Name, Email, PasswordHash)
  VALUES (N'Demo Donor', @DemoEmail, 0x01);
  SET @DonorID = SCOPE_IDENTITY();
END

-- 2) Ensure Gaza Relief project exists
DECLARE @GazaCatID INT = (SELECT CategoryID FROM dbo.DonationCategory WHERE Name = N'Gaza Relief');
IF @GazaCatID IS NULL
BEGIN
  RAISERROR('Gaza Relief category not found. Run the build script first.', 16, 1);
  RETURN;
END

DECLARE @ProjectID INT = (
  SELECT TOP 1 ProjectID FROM dbo.Project
  WHERE CategoryID = @GazaCatID AND Title = N'Demo Project - Gaza Relief'
  ORDER BY ProjectID DESC
);

IF @ProjectID IS NULL
BEGIN
  INSERT INTO dbo.Project (CategoryID, Title, Description, StartDate)
  VALUES (@GazaCatID, N'Demo Project - Gaza Relief', N'Demo project for smoke test', GETDATE());
  SET @ProjectID = SCOPE_IDENTITY();
END

-- 3) Ensure fundraiser exists
DECLARE @FundraiserID INT = (
  SELECT TOP 1 FundraiserID FROM dbo.Fundraiser
  WHERE ProjectID = @ProjectID AND Title = N'Demo Fundraiser 2025'
  ORDER BY FundraiserID DESC
);

IF @FundraiserID IS NULL
BEGIN
  INSERT INTO dbo.Fundraiser (ProjectID, Title, TargetAmount, StartDate, IsActive)
  VALUES (@ProjectID, N'Demo Fundraiser 2025', 50000, GETDATE(), 1);
  SET @FundraiserID = SCOPE_IDENTITY();
END

-- 4) Insert a succeeded donation of 1000 (always adds another donation)
INSERT INTO dbo.Donation (DonorID, FundraiserID, Amount, Status)
VALUES (@DonorID, @FundraiserID, 1000, 'succeeded');

-- 5) Show per-fundraiser totals (should include the new 1000)
SELECT TOP 1 v.*
FROM dbo.v_FundraiserCollected v
WHERE v.FundraiserID = @FundraiserID
ORDER BY v.FundraiserID DESC;

-- 6) Show segment totals for Gaza Relief (admin view)
SELECT *
FROM dbo.v_SegmentTotals
WHERE CategoryID = @GazaCatID;

-- 7) Show donor simple totals for Gaza Relief
SELECT *
FROM dbo.v_SegmentTotalsBasic
WHERE CategoryID = @GazaCatID;

PRINT 'Smoke test completed.';
